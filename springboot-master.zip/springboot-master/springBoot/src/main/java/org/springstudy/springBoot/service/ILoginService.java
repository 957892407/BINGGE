package org.springstudy.springBoot.service;

import org.springstudy.springBoot.beans.UserInfo;

public interface ILoginService {

	public boolean login(UserInfo user);
}
