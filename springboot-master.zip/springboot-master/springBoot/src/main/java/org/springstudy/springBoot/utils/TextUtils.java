package org.springstudy.springBoot.utils;

public class TextUtils {

	public static boolean isEmpty(Object obj) {
		if (obj == null) return true;
		else return false;
	}
}
