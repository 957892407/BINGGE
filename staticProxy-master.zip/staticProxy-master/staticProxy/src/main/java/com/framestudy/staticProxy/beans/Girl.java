package com.framestudy.staticProxy.beans;

public class Girl {

	private String name;

	public Girl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Girl(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
}
