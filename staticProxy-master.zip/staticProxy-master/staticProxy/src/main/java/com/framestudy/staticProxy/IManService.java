package com.framestudy.staticProxy;

public interface IManService {

	public void writeLetter();
	
	public void getFlower();
	
}
